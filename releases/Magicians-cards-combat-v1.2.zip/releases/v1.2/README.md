# v1.2 冻结卡牌与战斗效果

2026-10-29。183张卡牌、677份库存；临时正向数值与直接加伤采用加算叠加，负面效果按各卡词条处理。

- cards.json：完整冻结定义、费用、攻防、首次层与效果文案。
- combat-rules.json：冻结范围、触发上限、护盾牌分类与1000局基线引用。
- pool-counts.json：逐卡库存；6种初始牌及专精不进入市场。
- retired-cards.json：已退役标识，不得据旧报告恢复。
- freeze-manifest.json：受保护文件、运行时校验范围与备份包SHA256。

在项目根目录执行`python tools/verify_v12.py`。卡牌加载自动校验冻结定义、迭代顺序与受保护战斗实现，发现漂移即报错。格式调整不应改变解析后的卡牌定义；文档文件完整性另由核验工具检查。

完整卡表见[卡牌总表](../../docs/cards-v1.2/catalogue.md)，时序见[结算规范](../../docs/cards-v1.2/snapshot-contract.md)，确认依据见[冻结确认](../../docs/cards-v1.2/freeze-confirmation.md)。备份包为releases/Magicians-cards-combat-v1.2.zip。

基线是324000—324999的1000局加算版本。此次只澄清文案与增加冻结防护；数值、战斗行为、AI静态特征与模型权重保持。AI可继续独立训练，包内AI源码和配置是参考快照；后续AI修改不改变本冻结规则。v1.1客户端独立保留。
